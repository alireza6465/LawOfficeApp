using System;
using System.Windows.Forms;

namespace LawOfficeApp
{
    public class CheckForm : Form
    {
        public CheckForm()
        {
            Text = "ثبت چک (نسخه آزمایشی)";
            Width = 400; Height = 300;
            StartPosition = FormStartPosition.CenterParent;
        }
    }
}
