using System;
using System.Windows.Forms;

namespace LawOfficeApp
{
    public class ReminderForm : Form
    {
        public ReminderForm()
        {
            Text = "یادآور (نسخه آزمایشی)";
            Width = 400; Height = 300;
            StartPosition = FormStartPosition.CenterParent;
        }
    }
}
